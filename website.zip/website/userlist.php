<?php
    session_start();
    include "./classes/dbh.classes.php";
    include "./classes/login.classes.php";
    include "./classes/login-contr.classes.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <linK rel="stylesheet" href="project.css">
</head>
<body>
    <div id="header">
        <div id="title">
            <a href="index.php"><h1>WPGsneaks</h1></a>
        </div>
        <nav id="headernav">
            <ul>
                <?php
                    if(isset($_SESSION["useruid"])){
                        if (isset($_SESSION["admin"])){  
                ?>
                        <li><a href="userlist.php">Users</a></li>
                <?php
                        }
                ?>
                    <li><a href="create.php">Add Shoe</a></li>
                    <li><a href="#"><?php echo $_SESSION["useruid"]; ?></a></li>
                    <li><a href="includes/logout.inc.php">Logout</a></li>
                <?php
                    }
                    else{
                ?>
                    <li><a href="login.php">Login</a></li>
                <?php
                    }
                ?>
            </ul>
        </nav>
    </div>
    <div class="userlist">
        <a href="adduser.php">Add User</a>
        <?php
            $db = new login();
            $result = $db->getusers();
            if($result->rowCount() >0){ ?>
                <ul>
                    <?php while ($row = $result->fetch(PDO::FETCH_ASSOC)){ ?>

                    <li>
                        <?php echo $row['users_uid']?>
                        <a href="updateuser.php?id=<?php echo $row['user_id']?>">update</a>
                        <form action="includes/userdelete.php?id=<?php echo $row['user_id']?>" method="post">
                            <button type="submit" name = "submit">delete</button>
                        </form>
                    </li>
                    <?php }?>
                </ul>
            <?php }?>
    </div>
</body>
</html>