<?php
class login extends dbh{
    protected function getuser($uid, $pwd) {
        $stmt = $this-> connect()->prepare('SELECT users_pwd FROM users WHERE users_uid = ? OR users_email = ?;');
        
        
        if(!$stmt->execute(array($uid, $pwd))){
            $stmt = null;
            header("location: ../index.php?error=stmtfailed");
            exit();
        }

        if($stmt->rowCount()==0){
            $stmt = null;
            header("location: ../login.php?error=usernotfound");
            exit();
        }

        $pwdhashed = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $checkPwd = password_verify($pwd, $pwdhashed[0]["users_pwd"]);
        
        if(!$checkPwd){
            $stmt = null;
            header("location: ../login.php?error=wrongpassword");
            exit();
        }
        elseif($checkPwd = true){
            $stmt = $this-> connect()->prepare('SELECT * FROM users WHERE users_uid = ? OR users_email = ? AND users_pwd = ?');
            if(!$stmt->execute(array($uid, $uid, $pwd))){
                $stmt = null;
                header("location: ../index.php?error=stmtfailed");
                exit();
            }
            if($stmt->rowCount()==0){
                $stmt = null;
                header("location: ../login.php?error=usernotfound");
                exit();
            }
            $user = $stmt->fetchAll(PDO::FETCH_ASSOC);

            session_start();
            $_SESSION["userid"] = $user[0]["users_id"];
            $_SESSION["useruid"] = $user[0]["users_uid"];
            $_SESSION["admin"] = $user[0]["admin"];

            $stmt = null;
        }


        $stmt = null;
    }
    public function getusers(){
        $sql= "SELECT user_id,users_uid,users_pwd,users_email,admin FROM users";
        $stmt = $this->connect()->query($sql);
        return $stmt;
    }
    public function getuserinfo($user_id){
        $sql = "SELECT user_id, users_uid, users_pwd, users_email, admin FROM users WHERE user_id = :user_id";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(":user_id",$user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function deleteuser($user_id){
        $sql = "DELETE FROM users WHERE user_id = $user_id";
        $stmt = $this->connect()->query($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function edituser($user_id, $users_uid, $users_pwd, $users_email, $admin){
        $sql = "UPDATE users SET users_uid = :users_uid, users_pwd = :users_pwd, users_email = :users_email, admin = :admin WHERE user_id = :user_id";
        $stmt = $this->connect()->prepare($sql);
        $hashedpwd = password_hash($users_pwd, PASSWORD_DEFAULT);
        $stmt->bindParam(":users_uid",$users_uid, PDO::PARAM_STR);
        $stmt->bindParam(":users_pwd",$hashedpwd, PDO::PARAM_STR);
        $stmt->bindParam(":users_email",$users_email, PDO::PARAM_STR);
        $stmt->bindParam(":admin",$admin, PDO::PARAM_BOOL);
        $stmt->bindParam(":user_id",$user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
    }
    public function adduser($users_uid,$users_pwd,$users_email){
        $sql = "INSERT INTO users (users_uid, users_pwd, users_email) VALUES (:users_uid, :hashedpwd, :users_email)";
        $stmt = $this->connect()->prepare($sql);
        $hashedpwd = password_hash($users_pwd, PASSWORD_DEFAULT);
        $stmt->bindParam(":users_uid",$users_uid, PDO::PARAM_STR);
        $stmt->bindParam(":hashedpwd",$hashedpwd, PDO::PARAM_STR);
        $stmt->bindParam(":users_email",$users_email, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt;
    }
}
?>