<?php
class logincontr extends login{
    private $uid;
    private $pwd;
 

    public function __construct($uid, $pwd) {
        $this->uid = $uid;
        $this->pwd = $pwd;

    }

    public function loginuser(){
        if($this->emptyInput()==false){
            header("location: ../login.php?error=emptyinput");
            exit();
        }

        $this->getuser($this->uid, $this->pwd);
    }

    private function emptyInput(){
        $result = true;
        if(empty($this->uid) || empty($this->pwd)){
            $result = false;
        }
        else {
            $result = true;
        }
        return $result;
    }
}
?>