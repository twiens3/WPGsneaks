<?php
class signupcontr extends signup{
    private $uid;
    private $pwd;
    private $pwdrepeat;
    private $email;
    private $admin; 

    public function __construct($uid, $pwd, $pwdrepeat, $email, $admin) {
        $this->uid = $uid;
        $this->pwd = $pwd;
        $this->pwdrepeat = $pwdrepeat;
        $this->email = $email;
        $this->admin = $admin;
    }

    public function signupuser(){
        if($this->emptyInput()==false){
            header("location: ../login.php?error=emptyinput");
            exit();
        }
        if($this->pwdmatch()==false){
            header("location: ../login.php?error=password");
            exit();
        }
        if($this->uidtakencheck()==false){
            header("location: ../login.php?error=useroremailtaken");
            exit();
        }

        $this->setuser($this->uid, $this->pwd, $this-> email, $this->admin);
    }

    private function emptyInput(){
        $result = true;
        if(empty($this->uid) || empty($this->pwd) || empty($this->pwdrepeat) || empty($this->email)){
            $result = false;
        }
        else {
            $result = true;
        }
        return $result;
    }
    private function pwdmatch(){
        $result = true;
        if ($this->pwd !== $this->pwdrepeat){
            $result = false;
        }
        return $result;
    }
    private function uidtakencheck(){
        $result = true;
        if (!$this->checkuser($this->uid, $this->email)){
            $result = false;
        }
        return $result;
    }
}
?>