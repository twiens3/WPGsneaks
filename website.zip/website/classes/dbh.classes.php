<?php
class dbh {
    protected function connect(){
        try{
            $username = "root";
            $password = "";
            $dbh = new PDO('mysql:host=localhost;dbname=wpgsneaks', $username, $password);
            return $dbh;
        }
        catch(PDOException $e){
            print "error:" . $e->getmessage() . "<br/>";
            die();
        }
    }

}
?>