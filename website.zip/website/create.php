<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <linK rel="stylesheet" href="project.css">
</head>
<body>
    <div id="header">
        <div id="title">
            <a href="index.php"><h1>WPGsneaks</h1></a>
        </div>
        <nav id="headernav">
            <ul>
                <?php
                    if(isset($_SESSION["useruid"])){
                        if (isset($_SESSION["admin"])){    
                ?>
                        <li><a href="userlist.php">Users</a></li>
                <?php
                        }
                ?> 
                    <li><a href="#">Add Shoe</a></li>
                    <li><a href="#"><?php echo $_SESSION["useruid"]; ?></a></li>
                    <li><a href="includes/logout.inc.php">Logout</a></li>
                <?php
                    }
                    else{
                ?>
                    <li><a href="login.php">Login</a></li>
                <?php
                    }
                ?>
            </ul>
        </nav>
    </div>
    <div class="create-form">
        <form action="shoeincludes/connect.php" method="post" >
            <label id='labelforimage' for="image">picture of shoes</label>
            <input id='inputimage' type="file" name="image">
            <input id='inputdsc' type="text" name="description" placeholder="description">
            <label id='labelsize' for="size">Size(in Mens):</label>
            <select id='sizeselect' name="size">
                <option value="9">9</option>
                <option value="9.5">9.5</option>
                <option value="10">10</option>
                <option value="10.5">10.5</option>
                <option value="11">11</option>
                <option value="11.5">11.5</option>
                <option value="12">12</option>
            </select>
            <input id='inputprice' type="number" name="price" placeholder="price">
            <label id='labelforcond' for="condition">Condition:</label>
            <select id='condselect' name="condition">
                <option value="anew">Brand new</option>
                <option value="bslightly used">slightly used</option>
                <option value="cheavily used">heavily used</option>
            </select>
            <button id='addshoebutton' type="submit" name="submit">ADD SHOE</button>
            
        </form>
    </div>
    
</body>
</html>