<?php
if(isset($_POST["submit"])){
    $simage = $_POST["image"];
    $dsc = $_POST["description"];
    $ssize = $_POST["size"];
    $price = $_POST["price"];
    $cond = $_POST["condition"];

    include "../shoeclasses/dphshoe.php";
    include "../shoeclasses/shoeclass.php";
    include "../shoeclasses/shoe-contr.php";
    $newpost = new shoecontr($simage, $dsc, $ssize, $price, $cond);

    $newpost ->postshoe();

    header("location: ../index.php?error=none");
}
?>