<?php
if (isset($_POST["submit"])){
    include "../shoeclasses/dphshoe.php";
    include "../shoeclasses/shoeclass.php";
    include "../shoeclasses/shoe-contr.php";
    $item = $_POST['search'];

    header("location: ../searchresult.php?id=$item");
}

?>