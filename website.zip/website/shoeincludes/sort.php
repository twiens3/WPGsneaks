<?php
if (isset($_POST["submit"])){
    include "../shoeclasses/dphshoe.php";
    include "../shoeclasses/shoeclass.php";
    include "../shoeclasses/shoe-contr.php";
    $item = $_POST['sort'];

    header("location: ../sorted.php?id=$item");
}

?>