<?php
if (isset($_POST["submit"])){
    include "../shoeclasses/dphshoe.php";
    include "../shoeclasses/shoeclass.php";
    include "../shoeclasses/shoe-contr.php";
    $item = $_GET['id'];
    $deleteimage = new shoeclass();
    $deleteimage ->deleteimage($item);
    header("location: ../view.php?id=$item");
}

?>