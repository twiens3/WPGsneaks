<?php
class commentclass extends dbhcomm{
    protected function setcomment($comment, $shoe_id){
        $stmt = $this-> connect()->prepare("INSERT INTO comments (comment,shoe_id) VALUES (?, ?);");
        if(!$stmt->execute(array($comment, $shoe_id))){
            $stmt = null;
            header("location: ../index.php?error=stmtfailed");
            exit();
        }

        $stmt = null; 
    }

    public function getcomments($shoe_id){
        $sql="SELECT comment_id,comment, time FROM comments WHERE shoe_id = :shoe_id ORDER BY time DESC;";
        $stmt = $this->connect()->prepare($sql);
        $stmt -> bindParam(":shoe_id",$shoe_id,PDO::PARAM_INT);
        $stmt -> execute();
        return $stmt;
    }
    public function deletecomment($comment_id){
        $sql = "DELETE FROM comments WHERE comment_id = $comment_id";
        $stmt = $this->connect()->query($sql);
        return $stmt;
    }
}
?>