<?php
class commentcontr extends commentclass{
    private $comment;
    private $shoe_id;
    public function __construct($comment,$shoe_id){
        $this->comment = $comment;
        $this->shoe_id = $shoe_id;
 
    }
    public function postcomment(){

        $this->setcomment($this->comment, $this->shoe_id);
    }
}

?>