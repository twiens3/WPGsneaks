<?php
    session_start();
    include "./shoeclasses/dphshoe.php";
    include "./shoeclasses/shoeclass.php";
    include "./shoeclasses/shoe-contr.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <linK rel="stylesheet" href="project.css">
</head>
<body>
    <div id="header">
        <div id="title">
            <a href="index.php"><h1>WPGsneaks</h1></a>
        </div>
        <form action="shoeincludes/search.php" method="post">
            <input type="text" name="search" placeholder="search">
            <button type="submit" name="submit">search</button>
        </form>
        <nav id="headernav">
            <ul>
                <?php
                    if(isset($_SESSION["useruid"])){
                        if (isset($_SESSION["admin"])){  
                ?>
                        <li><a href="userlist.php">Users</a></li>
                <?php
                        }
                ?>
                    <li><a href="create.php">Add Shoe</a></li>
                    <li><a href="#"><?php echo $_SESSION["useruid"]; ?></a></li>
                    <li><a href="includes/logout.inc.php">Logout</a></li>
                <?php
                    }
                    else{
                ?>
                    <li><a href="login.php">Login</a></li>
                <?php
                    }
                ?>
            </ul>
        </nav>
    </div>
    <div class="itemlist">
            <?php
                $item = $_GET['id'];
                $db = new shoeclass();
                $result = $db-> searchshoe($item);
                if($result->rowCount() >0){ ?>
                    <ul>
                        <?php while ($row = $result->fetch(PDO::FETCH_ASSOC)){ ?>
                        <li id="thing">
                            <?php
                            if ($row['image'] !== "0"){
                                echo "<img id='image' src=images/{$row['image']} alt='shoe' width='210' height='180'>";
                            }?>
                            <a id="link" href="view.php?id=<?php echo $row['shoe_id']?>"><?php echo $row['description']?></a>
                        </li>
                        <?php }?>
                    </ul>
                <?php }?>
    </div>
</body>
</html>