<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <linK rel="stylesheet" href="project.css">
</head>
<body>
    <div id="header">
        <div id="title">
            <a href="index.php"><h1>WPGsneaks</h1></a>
        </div>
        <nav id="headernav">
            <ul>
                <?php
                    if(isset($_SESSION["useruid"])){  
                ?>
                    <li><a href="#"><?php echo $_SESSION["useruid"]; ?></a></li>
                    <li><a href="includes/logout.inc.php">Logout</a></li>
                <?php
                    }
                    else{
                ?>
                    <li><a href="login.php">Login</a></li>
                <?php
                    }
                ?>
            </ul>
        </nav>
    </div>
    <section class="index-login">
        <div class="wrapper">
            <div id="signup">
                <h4>sign up</h4>
                <form action="includes/signup.inc.php" method="post">
                    <input type="text" name="uid" placeholder="Username">
                    <input type="password" name="pwd" placeholder="Password">
                    <input type="password" name="pwdrepeat" placeholder="Repeat Password">
                    <input type ="text" name="email" placeholder="E-mail">
                    <input type="checkbox" name="admin"><label for="admin">admin</label>
                    <br>
                    <button type="submit" name="submit">sign up</button>
                </form>
            </div>
            <div id="login">
                <h4>login</h4>
                <form action="includes/login.inc.php" method="post">
                    <input type="text" name="uid" placeholder="Username">
                    <input type="password" name="pwd" placeholder="Password">
                    <br>
                    <button type="submit" name="submit">login</button>
                </form>
            </div>
        </div>
    </section>
</body>
</html>