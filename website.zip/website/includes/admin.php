<?php
if(isset($_POST["submit"])){
    $password = $_POST['password'];
    if ($password === "admin1"){
        header("location: ../userlist.php?error=none");
    }
    else{
        header("location: ../adminlogin.php?error=wrongpassword");
    }
}