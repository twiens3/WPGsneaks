<?php
if(isset($_POST["submit"])){
    $users_uid = $_POST["uid"];
    $users_pwd = $_POST["pwd"];
    $users_email = $_POST["email"];

    include "../classes/dbh.classes.php";
    include "../classes/login.classes.php";
    include "../classes/login-contr.classes.php";
    $adduser = new login();

    $adduser -> adduser( $users_uid, $users_pwd, $users_email);

    header("location: ../index.php?error=none");
}
?>