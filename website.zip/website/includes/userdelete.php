<?php
if (isset($_POST["submit"])){
    include "../classes/dbh.classes.php";
    include "../classes/login.classes.php";
    include "../classes/login-contr.classes.php";
    $item = $_GET['id'];
    $deleteuser = new login();
    $deleteuser ->deleteuser($item);
    header("location: ../userlist.php?error=none");
}

?>