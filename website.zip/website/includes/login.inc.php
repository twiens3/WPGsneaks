<?php
if(isset($_POST["submit"])){
    //grabbing data
    $uid = $_POST["uid"];
    $pwd = $_POST["pwd"];


    //create signup class
    include "../classes/dbh.classes.php";
    include "../classes/login.classes.php";
    include "../classes/login-contr.classes.php";
    $login = new logincontr($uid, $pwd);

    $login->loginuser();

    header("location: ../index.php?error=none");
}
?>