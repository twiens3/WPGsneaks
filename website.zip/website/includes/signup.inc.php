<?php
if(isset($_POST["submit"])){
    //grabbing data
    $uid = $_POST["uid"];
    $pwd = $_POST["pwd"];
    $pwdrepeat = $_POST["pwdrepeat"];
    $email = $_POST["email"];
    $admin = $_POST["admin"];

    //create signup class
    include "../classes/dbh.classes.php";
    include "../classes/signup.classes.php";
    include "../classes/signup-contr.classes.php";
    $signup = new signupcontr($uid, $pwd, $pwdrepeat, $email, $admin);

    $signup->signupuser();

    header("location: ../index.php?error=none");
}
?>