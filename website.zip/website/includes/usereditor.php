<?php
if(isset($_POST["submit"])){
    $users_uid = $_POST["uid"];
    $users_pwd = $_POST["pwd"];
    $users_email = $_POST["email"];
    $item = $_GET['id'];

    include "../classes/dbh.classes.php";
    include "../classes/login.classes.php";
    include "../classes/login-contr.classes.php";
    $edituser = new login();

    $edituser -> edituser($item, $users_uid, $users_pwd, $users_email, $admin);

    header("location: ../index.php?error=none");
}
?>