<?php
class shoecontr extends shoeclass{
    private $simage;
    private $dsc;
    private $ssize;
    private $price;
    private $cond;
    public function __construct($simage, $dsc, $ssize, $price, $cond){
       $this->simage = $simage;
       $this->dsc = $dsc;
       $this->ssize = $ssize;
       $this->price = $price;
       $this->cond = $cond; 
    }

    public function postshoe(){
        if($this->emptyInput()==false){
            header("location: ../create.php?error=emptyinput");
            exit();
        }
        $this->setshoe($this->simage, $this->dsc, $this->ssize, $this->price, $this->cond);
    }

    private function emptyInput(){
        $result = true;
        if(empty($this->dsc) || empty($this->price)){
            $result = false;
        }
        return $result;
    }
    public function testimage(){
        $result = true;
        $allowed=['jpeg', 'png'];
        $filemime = mime_content_type($this->simage);
        if (!in_array($filemime,$allowed)){
            $result=false;
        }
        return $result;
    }

}
?>