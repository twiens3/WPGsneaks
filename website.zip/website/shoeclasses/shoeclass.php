<?php
class shoeclass extends dphshoe{
    protected function setshoe($simage, $dsc, $ssize, $price, $cond){
        $stmt = $this-> connect()->prepare("INSERT INTO shoes (image,description,size,price,shoe_condition) VALUES (?, ?, ?, ?, ?);");
        if(!$stmt->execute(array($simage, $dsc, $ssize, $price, $cond))){
            $stmt = null;
            header("location: ../index.php?error=stmtfailed");
            exit();
        }

        $stmt = null; 
    }
    public function getshoes(){
        $sql = "SELECT shoe_id,image, description, size, price, shoe_condition FROM shoes";
        $stmt = $this->connect()->query($sql);
        return $stmt;
    }
    public function getshoe($shoe_id){
        $sql = "SELECT shoe_id,image,description, size, price, shoe_condition FROM shoes WHERE shoe_id = :shoe_id";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(":shoe_id",$shoe_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function deleteshoe($shoe_id){
        $sql = "DELETE FROM shoes WHERE shoe_id = $shoe_id";
        $stmt = $this->connect()->query($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function editshoe($shoe_id, $dsc, $ssize, $price, $cond){
        $sql = "UPDATE shoes SET description = :dsc, size = :ssize, price = :price, shoe_condition = :cond WHERE shoe_id = :shoe_id";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(":dsc",$dsc, PDO::PARAM_STR);
        $stmt->bindParam(":ssize",$ssize, PDO::PARAM_STR);
        $stmt->bindParam(":price",$price, PDO::PARAM_INT);
        $stmt->bindParam(":cond",$cond, PDO::PARAM_STR);
        $stmt->bindParam(":shoe_id",$shoe_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
        
    }
    public function searchshoe($item){
        $sql = "SELECT shoe_id,image,description,size,price,shoe_condition FROM shoes WHERE description like :item";
        $stmt=$this->connect()->prepare($sql);
        $term="%". $item . "%";
        $stmt ->bindParam(":item",$term,PDO::PARAM_STR);
        $stmt->execute();
        return $stmt;
    }
    public function sortshoes($item){
        if ($item === "price"){
            $sql = "SELECT shoe_id,image,description,size,price,shoe_condition FROM shoes ORDER BY price";
        }
        if ($item === "size"){
            $sql = "SELECT shoe_id,image,description,size,price,shoe_condition FROM shoes ORDER BY size";
        }
        if ($item === "condition"){
            $sql = "SELECT shoe_id,image,description,size,price,shoe_condition FROM shoes ORDER BY shoe_condition";
        }
        $stmt = $this->connect()->prepare($sql);
        $stmt ->execute();
        return $stmt;
    }
    public function deleteimage($item){
        $sql = "UPDATE shoes SET image = 0 WHERE shoe_id = :item";
        $stmt=$this->connect()->prepare($sql);
        $stmt->bindParam(":item",$item,PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
    }
}
?>