<?php
    session_start();
    include "./shoeclasses/dphshoe.php";
    include "./shoeclasses/shoeclass.php";
    include "./shoeclasses/shoe-contr.php";
    include "./commentclass/dbhcomm.php";
    include "./commentclass/commentclass.php";
    include "./commentclass/comm-contr.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <linK rel="stylesheet" href="project.css">
</head>
<body>
    <div id="header">
        <div id="title">
            <a href="index.php"><h1>WPGsneaks</h1></a>
        </div>
        <form action="shoeincludes/search.php" method="post">
            <input type="text" name="search" placeholder="search">
            <button type="submit" name="submit">search</button>
        </form>
        <nav id="headernav">
            <ul>
                <?php
                    if(isset($_SESSION["useruid"])){  
                        if (isset($_SESSION["admin"])){
                ?>
                            <li><a href="userlist.php">Users</a></li>
                <?php
                        }
                ?> 
                    <li><a href="create.php">Add Shoe</a></li>
                    <li><a href="#"><?php echo $_SESSION["useruid"]; ?></a></li>
                    <li><a href="includes/logout.inc.php">Logout</a></li>
                <?php
                    }
                    else{
                ?>
                    <li><a href="login.php">Login</a></li>
                <?php
                    }
                ?>
            </ul>
        </nav>
    </div>
    <div class="display">
        <?php
        $item = $_GET['id'];
        $db = new shoeclass();
        $shoe = $db->getshoe($item);
        if ($shoe['image'] !== "0"){
            echo "<img id='view'src=images/{$shoe['image']} alt='shoe' width='700'>";
        }
        echo "<p id='dsc'>{$shoe['description']}</p>";
        echo "<p id='size1'>size:</p>";
        echo "<p id='size2'>{$shoe['size']}</p>";
        echo "<p id='price1'>price:</P>";
        $d = "<p id='price2'>$";
        echo "$d{$shoe['price']}</p>";
        echo "<p id='cond1'>condition:</p>";
        echo "<p id='cond2'>{$shoe['shoe_condition']}</p>";
        ?>
        <h4 id="commenttitle"> Comments </h4>
        <?php
            $dbc = new commentclass();
            $resultc = $dbc -> getcomments($item);
            if($resultc->rowCount() >0){ ?>
                <ul id='commentlist'>
                    <?php while ($row = $resultc->fetch(PDO::FETCH_ASSOC)){ ?>
                    <li>
                        <p id='comment' ><?php echo $row['comment']?></p>
                        <?php
                            if (isset($_SESSION["admin"])){
                        ?>
                            <form id= 'deletecomment' action="commentinc/deletecomment.php?id=<?php echo $row['comment_id']?>" method="post">
                                <button id='deletecommentbutton' type="submit" name="submit">delete</button>
                            </form>
                        <?php } ?>
                    </li>
                    <?php }?>
                </ul>
        <?php }
        if(isset($_SESSION["useruid"])){
        ?>
            <form id='createcomment' action="commentinc/comment.php?id=<?php echo $item?>" method="post">
                <label id='commentlabel' for="comment">leave a comment</label>
                <textarea id='newcomment' name="comment" rows="5" cols="50"></textarea>
                <button id='commentbutton' type="submit" name = "submit">submit</button>
            </form>
        <?php
        }
        ?>
        <?php
            if (isset($_SESSION["admin"])){
        ?>
            <form id='deleteshoe' action="shoeincludes/shoedelete.php?id=<?php echo $item?>" method="post">
                <button id='deleteshoebutton' type="submit" name = "submit">delete</button>
            </form>
        <?php
            if ($shoe['image'] !== "0"){
        ?>
                <form id='deleteimage' action="shoeincludes/imagedelete.php?id=<?php echo $item?>" method="post">
                    <button id='deleteimagebutton' type="submit" name = "submit">delete image</button>
                </form>
        <?php
            }
        ?>
            <a id='editorlink' href="editor.php?id=<?php echo $item ?>">edit</a>
        
        
        <?php
        }
        ?>
        
    </div>
</body>
</html>