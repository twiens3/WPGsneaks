<?php
    session_start();
    include "./shoeclasses/dphshoe.php";
    include "./shoeclasses/shoeclass.php";
    include "./shoeclasses/shoe-contr.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <linK rel="stylesheet" href="project.css">
</head>
<body>
    <div id="header">
        <div id="title">
            <a href="index.php"><h1>WPGsneaks</h1></a>
        </div>
        <form action="shoeincludes/search.php" method="post">
            <input type="text" name="search" placeholder="search">
            <button type="submit" name="submit">search</button>
        </form>
        <nav id="headernav">
            <ul>
                <?php
                    if(isset($_SESSION["useruid"])){
                        if (isset($_SESSION["admin"])){  
                ?>
                        <li><a href="adminlogin.php">Users</a></li>
                <?php
                        }
                ?>
                    <li><a href="create.php">Add Shoe</a></li>
                    <li><a href="#"><?php echo $_SESSION["useruid"]; ?></a></li>
                    <li><a href="includes/logout.inc.php">Logout</a></li>
                <?php
                    }
                    else{
                ?>
                    <li><a href="login.php">Login</a></li>
                <?php
                    }
                ?>
            </ul>
        </nav>
    </div>
    <div>
        <form action="includes/admin.php" method="post">
            <input type="text" name="password" placeholder="password">
            <button type="submit" name="submit">submit</button>
        </form>
    </div>
</body>
</html>