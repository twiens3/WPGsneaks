<?php
if(isset($_POST["submit"])){
    $comment = $_POST["comment"];
    $item = $_GET['id'];

    include "../commentclass/dbhcomm.php";
    include "../commentclass/commentclass.php";
    include "../commentclass/comm-contr.php";

    $newcomment = new commentcontr($comment,$item);

    $newcomment ->postcomment();

    header("location: ../view.php?id=$item");
}
?>