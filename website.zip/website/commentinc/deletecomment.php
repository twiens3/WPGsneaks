<?php
if (isset($_POST["submit"])){
    include "../commentclass/dbhcomm.php";
    include "../commentclass/commentclass.php";
    include "../commentclass/comm-contr.php";
    $item = $_GET['id'];
    $deletecomment = new commentclass();
    $deletecomment ->deletecomment($item);
    header("location: ../index.php?error=none");
}

?>